// Flutter app pub get

import 'package:get/get.dart';

class CalcuControladores extends GetXController {
  
  var firstNumber = '0'.obs;
  var secondNumber = '0'.obs;
  var mathResultNumber = '0'.obs;


}
